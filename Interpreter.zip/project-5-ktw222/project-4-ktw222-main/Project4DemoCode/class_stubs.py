# this file is provided to allow the type checking to not throw errors in VSCODE
# for the full project delete this file and instead include the files you copied over
# from projects 1 & 2
class DatalogProgram:
    ...

class Predicate:
    ...

class Token:
    ...
    
class Lexer:
    ...
    
class Parser:
    ...

class Rule:
    ...
