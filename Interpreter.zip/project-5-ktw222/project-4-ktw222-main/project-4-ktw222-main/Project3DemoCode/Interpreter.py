from .Relation import Relation
from .Row import Row
from .Header import Header
from typing import Dict
from Project3DemoCode.project_2_classes.parser import DatalogProgram
from Project3DemoCode.project_2_classes.parser import Predicate
from Project3DemoCode.project_2_classes.parser import Rules
import copy
# remove this and delete the file 
# after you add in your code from project 2
#from class_stubs import * 

class Interpreter:
    def __init__(self) -> None:
        self.output_str: str = ""
        self.database: Dict[str, Relation] = {}
        pass
    
    def run(self, datalog_program: DatalogProgram) -> str:
        self.datalog_program: DatalogProgram = datalog_program
        self.interpret_schemes()
        self.interpret_facts()
        self.interpret_rules()
        self.interpret_queries()
        return self.output_str #append to self.output_str rather than printing to console
    
    def interpret_schemes(self) -> None:
        # Start with an empty Database. 
        #for Schemes in DatalogProgram:
        for scheme in self.datalog_program.scheme_list:
            relation_name = scheme.name
            header = Header(scheme.parameters)
            new_relation = Relation(relation_name, header, set())
            self.database[scheme.name] = new_relation

        # For each scheme in the Datalog program, 
        #   add an empty Relation to the Database. 
        #   Use the scheme name as the name of the relation 
        #   and the attribute list from the scheme as the header of the relation.
    
    def interpret_facts(self) -> None:
        # For each fact in the Datalog program, 
        for fact in self.datalog_program.fact_list:
            row : Row
            row = Row(fact.parameters)
            if fact.name in self.database.keys():
        #   add a Tuple to a Relation. //in database
                self.database[fact.name].add_row(row)
        #print("in facts")
        #   Use the predicate name from the fact to 
        #   determine the Relation to which the Tuple should be added. 

        #   Use the values listed in the fact to provide the values for the Tuple.

    
    def interpret_queries(self) -> None:
        #print("queries")
        self.output_str += f"Query Evaluation\n"
        for query in self.datalog_program.query_list:
            evaluated_query = self.evaluate_predicate(query)
            self.output_str += f"{query.to_string()}? "
            if len(evaluated_query.rows) == 0:
                self.output_str += "No\n"
            else:
                self.output_str += f"Yes({len(evaluated_query.rows)})\n"
                #maybe put an if statement here?
                for row in sorted(evaluated_query.rows):
                    self.output_str += "  "
                    for i in range(len(evaluated_query.header.values)): #header range
                        #attribute = evaluated_query.header.values[i]
                        value = row.values[i]
                        query_attribute = evaluated_query.header.values[i]

                        self.output_str += f"{query_attribute}={value}, "
                    self.output_str = self.output_str[:-2]
                    if len(row.values) > 0:
                        self.output_str += "\n" #This is the problem :)
        
                    #if i < len(evaluated_query.rows) - 1:
                        #self.output_str += ", "
                        #self.output_str += "\n"
        # for each query in the datalog_program call evaluate predicate.
            # append the predicate returned by this function to the output string
            
        # output notes:
        # For each query, output the query and a space. 
        # If the relation resulting from evaluating the query is empty, output 'No'. 
        # If the resulting relation is not empty, output 'Yes(n)' where n is the number of tuples in the resulting relation.
        
        # If there are variables in the query, output the tuples from the resulting relation.

        # Output each tuple on a separate line as a comma-space-separated list of pairs.
        # Each pair has the form N='V', 
        # where N is the attribute name from the header and V is the value from the tuple. 
        # Output the name-value pairs in the same order as the variable names appear in the query. 
        # Indent the output of each tuple by two spaces.
        
        # some of this output code was given to you in the Relation.__str__() function. 
        # It may need to be modified slightly

        # Output the tuples in sorted order. 
        # Sort the tuples alphabetically based on the values in the tuples. 
        # Sort first by the value in the first position and if needed up to the value in the nth position.
        return self.output_str
        pass
    
    def evaluate_predicate(self, predicate: Predicate) -> Predicate: #reuse this logic for project 4 so probably do it this way to save yourself work in the future.
        # For this predicate you need to use a sequence of select, project, and rename operations on the Database 
        # to evaluate the query. Evaluate the queries in the order given in the input.
        # Get the Relation from the Database with the same name as the predicate name in the query.
        name_of_query = predicate.name
        new_relation = copy.deepcopy(self.database[name_of_query])
        #IMPLEMENTATION OF SELECT 1 AND SELECT 2
        parameterIndex: int = 0
        IDs : list[str] = []
        colIndexes : list[int] = []
        index1:int = 0
        for parameter in predicate.parameters:
            #parameterIndex += 1
            dict_of_queries: Dict(str, int) = {}
            dict_of_queries = {parameter, parameterIndex}
            isConst : bool = 0
            isID: bool = 0
            haveSeenID: bool = 0
            
            if parameter[0] == '\'':
                isConst = 1
            else:
                isID = 1
            
            if isConst == 1:
                new_relation = new_relation.select1(parameter, parameterIndex)
                #colIndexes.append(parameterIndex)
                #IDs.append(parameter)
                parameterIndex += 1
            #if is a constant SELECT1
            #if we have seen it SELECT2
            elif isID == 1:
                #for index in IDs:
                    #if index in IDs == parameter:
                        #haveSeenID = 1
                        #index1 = dict_of_queries[parameter]
                        
                #if haveSeenID == 1:
                if parameter in IDs:
                    #index1 = dict_of_queries[parameter]
                    index1 = IDs.index(parameter)
                    #colIndexes.append(parameterIndex)
                    #IDs.append(parameter)
                    new_relation = new_relation.select2(index1, parameterIndex)
                    parameterIndex += 1
                else:
                    colIndexes.append(parameterIndex)
                    index1 = parameterIndex
                    parameterIndex += 1
                    IDs.append(parameter)



                #if we have not seen it we are going to mark add to helper variables (our dict and lists)
        #IMPLEMENTATION OF PROJECT
        new_relation = new_relation.project(colIndexes)
        
        #print(new_relation)
        #implementation of RENAME
        new_relation = new_relation.rename(Header(IDs))
        #print(new_relation.rename(IDs))

        return new_relation

        
            
        # Use one or more select operations to select the tuples from the Relation that match the query. 
        # Iterate over the parameters of the query: 
        # If the parameter is a constant, select the tuples from the Relation that have the same value as the constant in the same position as the constant. 
        # If the parameter is a variable and the same variable name appears later in the query, 
        # select the tuples from the Relation that have the same value in both positions where the variable name appears.

        # After selecting the matching tuples, use the project operation 
        #   to keep only the columns from the Relation that correspond to the 
        #   positions of the variables in the query. Make sure that each variable name appears only once in the resulting relation. If the same name appears more than once, keep the first column where the name appears and remove any later columns where the same name appears. (This makes a difference when there are other columns in between the ones with the same name.)
        # After projecting, use the rename operation to 
        #   rename the header of the Relation to the
        #   names of the variables found in the query.
        # The operations must be done in the order described above: 
        #   any selects, 
        #   followed by a project, 
        #   followed by a rename.
        # return the new predicate
        # int is where you saw it
        #lists maintain order can use them for renam and project
    
    # this will be implemented during project 4
    def interpret_rules(self) -> None:
        # fixed point algorithm to evaluate rules goes here: #move from interprate query to interpret predicate
        self.output_str += f"Rule Evaluation\n"
        ruleCounter: int = 0
        changed: bool = True
        og_set: set()
        curr_evaluated_rule: int = 0
        while changed == True:
            changed = False
            ruleCounter += 1
            for rule in self.datalog_program.rule_list:
                #og_set = self.database[rule.head_predicate.name].rows
                self.output_str += f"{rule.to_string()}\n"
                evaluated_rule = self.evaluate_rule(rule)
                #ruleCounter += 1
                
                #self.output_str += f"{og_set.difference(self.database[rule.head_predicate.name].rows)}"
                if evaluated_rule > 0:
                    changed = True
                    #curr_evaluated_rule += evaluated_rule
                    #ruleCounter += 1 ##create independent function database.get_size
        self.output_str += f"\nSchemes populated after {ruleCounter} passes through the Rules.\n\n" # was evaluated rule
            
            #if len(evaluated_rule.rows) == 0:
                #self.output_str += "No\n"
            #else:
                #self.output_str += f"Yes({len(evaluated_rule.rows)})\n"
                #maybe put an if statement here?
                #for row in sorted(evaluated_rule.rows):
                    #self.output_str += "  "
                    #for i in range(len(evaluated_rule.header.values)): #header range
                        #attribute = evaluated_query.header.values[i]
                        #value = row.values[i]
                        #rule_attribute = evaluated_rule.header.values[i]

                        #self.output_str += f"{rule_attribute}={value}, "
                    #self.output_str = self.output_str[:-2]
                    #if len(row.values) > 0:
                        #self.output_str += "\n"
        return self.output_str
        pass
    
    # this function should return the number of unique tuples added to the database
    def evaluate_rule(self, rule: Rules) -> int:
        colsToProject : list[int] = []
        variableNames: list = []
        # Step 1:
        resultList: list = [] #update
        changed: bool = True
        #numRules: int = 0
        #while (changed == True): #move this to interpret
            #changed = False
        for predicate in rule.rule_list:
            result = self.evaluate_predicate(predicate)
            #print(result)
            #colIndexes += 
            resultList.append(result)
            #print(resultList)
        new_result: Relation
        new_result = resultList[0]
        if len(resultList) >= 2:
            #print("in >= 2")
            for result in resultList:
                new_result = new_result.natural_join(result)
                #print("just natural joined: Result =")
                #print(result)
                #print("new result =")
                #print(new_result)
        #elif len(resultList) == 1:
            #print("in == 1")
            #is_unique:bool = True
        for i in rule.head_predicate.parameters: #trying to use the tuple in the head predicate
            index = 0
            for j in new_result.header.values:
                if j == i:
                    colsToProject.append(index)
                index += 1
                        #just do it where they match
                    #print("in nested for loop")
                        #while is_unique == True:
            #if result.header.values == rule.head_predicate.parameters:
                #print("in update varNames")
                        #colsToProject.append(result.header.values.index(j))
                #variableNames.append(i) #finding where they match
                #print(variableNames)
                        #is_unique = False
            #if result.header.values.index(i) != result.header.values:
                #print("in update colsToProject")
                #colsToProject.append(result.header.values.index(i))
                #print(colsToProject)
                    #is_unique = False
        new_result = new_result.project(colsToProject)
        #print(new_result.header.values)

        val_to_rename: Header = Header(rule.head_predicate.parameters)
        new_result = new_result.rename(val_to_rename) #change
        size_before: int = len(self.database[rule.head_predicate.name].rows)
        print(size_before)

        #old_rows = self.database[rule.head_predicate.name].rows
        #new_rows = new_result.rows
        #self.output_str += f"{new_rows.difference(old_rows)}"
        self.database[rule.head_predicate.name], self.output_str = self.database[rule.head_predicate.name].union(new_result, self.output_str, rule) #change
        #after_rows = before_rows = self.database[rule.head_predicate.name].rows
        size_after: int = len(self.database[rule.head_predicate.name].rows)
        print(size_after)
            #if (size_after > size_before):
                #changed = True
        
        return size_after - size_before