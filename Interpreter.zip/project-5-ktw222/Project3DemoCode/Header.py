class Header:
    def __init__(self, values: list[str]) -> None:
        self.values: list[str] = values

    def get_len(self) -> int:
        ... #could choose to do this
    